import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, InsertResult, FindConditions, UpdateResult, DeleteResult } from 'typeorm';
import { User } from './user.entity';
const bcrypt_1 = require("bcrypt");

const constants_1 = require("./constants");


@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>
  ) {}

  findOne(query: any): any {
    console.log("inside findOne ::: ", query);
    return this.userRepository.findOne(query);
  }

  find(query: any) : any {
    return this.userRepository.find(query);
  }

  

  async createUser(user: any): Promise<InsertResult> {
    try {

      const userEntity = this.userRepository.create(user);

      const res = await this.userRepository.insert(userEntity);

      Logger.log('createUser - Created user');

      return res;
    } catch(e) {
      Logger.log(e);
      throw e;
    }
  }

  async updateUser(username: any, user : any) : Promise<UpdateResult> {
    try{
      console.log(username);
      console.log(user);
      if(user.password){
        user.password = await(bcrypt_1.hash(user.password, 10));
      }
      const res = await this.userRepository.update({username:username}, user);

      Logger.log('UpdateUser - Updated User');

      return res;

    } catch(e) {
      Logger.log(e);
      throw e;
    }
  }

  async deleteUser(username:any) : Promise<DeleteResult>{
    try{
      const res = await this.userRepository.delete({username:username});

      Logger.log('DeleteUser - Deleted User');

      return res;
    }catch(e){
      Logger.log(e);
      throw e;
    }
  }
}