import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './user/user.entity';
import { UserModule } from './user/user.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
    type: 'postgres',
    host: 'localhost',
    port: 5432,
    username: 'muralin',
    password: 'password',
    database: 'userdb',
    synchronize: true,
    entities: [User]
  }), UserModule],
})
export class AppModule { }
